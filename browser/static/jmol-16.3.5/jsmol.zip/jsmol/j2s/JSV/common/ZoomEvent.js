Clazz.declarePackage("JSV.common");
(function(){
var c$ = Clazz.declareType(JSV.common, "ZoomEvent", null);
/*LV!1824 unnec constructor*/})();
;//5.0.1-v4 Tue Nov 12 14:58:21 CST 2024
