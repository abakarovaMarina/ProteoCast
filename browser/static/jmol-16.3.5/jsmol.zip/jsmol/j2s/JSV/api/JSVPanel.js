Clazz.declarePackage("JSV.api");
Clazz.declareInterface(JSV.api, "JSVPanel", JSV.api.JSVViewPanel);
;//5.0.1-v4 Tue Nov 12 14:58:21 CST 2024
