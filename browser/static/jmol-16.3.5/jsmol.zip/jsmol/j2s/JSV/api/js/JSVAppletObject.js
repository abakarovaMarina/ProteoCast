Clazz.declarePackage("JSV.api.js");
Clazz.declareInterface(JSV.api.js, "JSVAppletObject", javajs.api.js.JSAppletObject);
;//5.0.1-v4 Tue Nov 12 14:58:21 CST 2024
