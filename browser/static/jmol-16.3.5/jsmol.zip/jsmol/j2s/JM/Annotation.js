Clazz.declarePackage("JM");
Clazz.load(["JM.ProteinStructure"], "JM.Annotation", null, function(){
var c$ = Clazz.declareType(JM, "Annotation", JM.ProteinStructure);
});
;//5.0.1-v4 Tue Nov 12 14:58:21 CST 2024
