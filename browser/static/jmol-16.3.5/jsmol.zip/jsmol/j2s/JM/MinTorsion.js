Clazz.declarePackage("JM");
Clazz.load(["JM.MinObject"], "JM.MinTorsion", null, function(){
var c$ = Clazz.declareType(JM, "MinTorsion", JM.MinObject);
Clazz.makeConstructor(c$, 
function(data){
Clazz.superConstructor (this, JM.MinTorsion, []);
this.data = data;
}, "~A");
});
;//5.0.1-v4 Tue Nov 12 14:58:21 CST 2024
