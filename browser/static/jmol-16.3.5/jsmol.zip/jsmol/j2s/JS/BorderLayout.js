Clazz.declarePackage("JS");
Clazz.load(["JS.LayoutManager"], "JS.BorderLayout", null, function(){
var c$ = Clazz.declareType(JS, "BorderLayout", JS.LayoutManager);
});
;//5.0.1-v4 Tue Nov 12 14:58:21 CST 2024
