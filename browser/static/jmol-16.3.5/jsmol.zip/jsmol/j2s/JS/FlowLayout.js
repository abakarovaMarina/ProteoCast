Clazz.declarePackage("JS");
Clazz.load(["JS.LayoutManager"], "JS.FlowLayout", null, function(){
var c$ = Clazz.declareType(JS, "FlowLayout", JS.LayoutManager);
});
;//5.0.1-v4 Tue Nov 12 14:58:21 CST 2024
