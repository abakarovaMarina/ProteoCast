Clazz.declarePackage("JS");
Clazz.load(["JS.JComponent"], "JS.JComponentImp", null, function(){
var c$ = Clazz.declareType(JS, "JComponentImp", JS.JComponent);
Clazz.overrideMethod(c$, "toHTML", 
function(){
return null;
});
});
;//5.0.1-v4 Tue Nov 12 14:58:21 CST 2024
